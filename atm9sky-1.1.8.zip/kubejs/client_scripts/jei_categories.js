JEIEvents.removeCategories(event => {
  event.remove('exdeorum:compressed_sieve')
})