StartupEvents.registry('item', event => {
    event
    .create('universal_press')
    .texture('kubejs:item/universal_press')
    .maxStackSize(64)
    .displayName('Universal Press');  
})
