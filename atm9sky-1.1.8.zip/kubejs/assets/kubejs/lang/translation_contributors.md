# Translation Contributors
(bullet list, <name(discord/github)> github/other link)

English, AllTheMods Team and quest devs/contributors,
- ToshibaMicrowave (https://github.com/ToshibaEC0Microwave)
- AlfredGG (https://github.com/alfredggttv)
- Toblerone0508 (https://github.com/TheBedrockMaster)
- Elite (https://github.com/Elite63719)
- Jonh09 (https://github.com/Jmpp2909)


Japanese,
- flll (https://github.com/flll)

French, (partial, needs updating)
- FabLeKebab (https://github.com/FabLeKebab)

Spanish,
- radzratz (https://github.com/RadzRatz)
- 102389 (https://github.com/102389)
- Arivio (https://github.com/Arivios)
- Metabodiru (https://github.com/Drox17)

Norwegian (BokMål)
- Permest (https://github.com/Permest)

Korean (packmenu buttons)
- ArcTrooper (https://github.com/ArcTrooper210)

Portuguese 
- oRuiva (https://github.com/oRuiva)