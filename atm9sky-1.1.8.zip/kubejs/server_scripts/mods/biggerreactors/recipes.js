// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 9: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

ServerEvents.recipes(allthemods => {
    allthemods.remove({ id: 'biggerreactors:compat/mekanism/enriching/enrichment_deepslate_uranium_ore' })
    allthemods.remove({ id: 'biggerreactors:compat/mekanism/enriching/enrichment_uranium_chunk' })
    allthemods.remove({ id: 'biggerreactors:compat/mekanism/enriching/enrichment_uranium_ore' })
    allthemods.remove({ id: 'biggerreactors:compat/mekanism/crushing/crusher_uranium_ingot' })
})

// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 9: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.