// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 9: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

ServerEvents.recipes(event =>{
    event.shaped('minecraft:elytra',
        [
            "aba",
            "cdc",
            "c c"
        ], {
        a: "minecraft:diamond",
        b: "minecraft:string",
        c: "minecraft:phantom_membrane",
        d: "minecraft:nether_star"
    })

    event.shaped('minecraft:sculk',
        [
            'AAA',
            'AAA',
            'AAA'
        ], {
        A: 'minecraft:echo_shard'
    })
})

// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 9: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.
