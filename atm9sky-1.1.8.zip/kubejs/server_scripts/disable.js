ServerEvents.recipes(event => {
    event.remove({ id:'ae2:network/blocks/spatial_anchor' })
    event.remove({ id:'mekanism:dimensional_stabilizer'})
    event.remove({ id:'darksmithing:netherite_upgrade_smithing_template'})
})